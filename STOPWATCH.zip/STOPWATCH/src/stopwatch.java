public class stopwatch extends javax.swing.JFrame{
	
	
	static int miliseconds = 0;
	static int seconds = 0;
	static int minutes = 0;
	static int hours = 0;
	
	static boolean state = true;
	public stopwatch() {
		initComponents();
	}
	
	@SuppressWarnings("unchecked")
	private void initComponents() {
		minute = new javax.swing.JLabel();
		second = new javax.swing.JLabel();
		milisecond = new javax.swing.JLabel();
		hour = new javax.swing.JLabel();
		JButton1 = new javax.swing.JButton();
		JButton4 = new javax.swing.JButton();
		JButton5 = new javax.swing.JButton();
		
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setTitle("StopWatch");
		minute.setFont(new java.awt.Font("Times New Roman",0,48));
		minute.setText("00 :");
		
		second.setFont(new java.awt.Font("Times New Roman",0,48));
		second.setText("00 :");
		
		milisecond.setFont(new java.awt.Font("Times New Roman",0,48));
		milisecond.setText("00 :");
		
		hour.setFont(new java.awt.Font("Times New Roman",0,48));
		hour.setText("00 :");
		
		JButton1.setFont(new java.awt.Font("Times New Roman",0,24));
		JButton1.setText("Stop");
		JButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				JButton1ActionPerformed(evt);
			}
		});
		
		JButton4.setFont(new java.awt.Font("Times New Roman",0,24));
		JButton4.setText("Reset");
		JButton4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				JButton4ActionPerformed(evt);
			}
		});
		

		JButton5.setFont(new java.awt.Font("Times New Roman",0,24));
		JButton5.setText("Start");
		JButton5.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				JButton5ActionPerformed(evt);
			}
		});
		
		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
						.addContainerGap()
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addComponent(JButton5)
								.addComponent(hour,javax.swing.GroupLayout.Alignment.TRAILING)
								)
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(layout.createSequentialGroup()
										.addGap(6,6,6)
										.addComponent(minute)
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(second)
										.addGap(10,10,10)
										.addComponent(milisecond)
										)
								.addGroup(layout.createSequentialGroup()
										.addGap(27,27,27)
										.addComponent(JButton1)
										.addGap(28,28,28)
										.addComponent(JButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE) ))
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE) )
				);
		
		layout.setVerticalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
						.addContainerGap()
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(hour)
								.addComponent(minute)
								.addComponent(second)
								.addComponent(milisecond)
								)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(JButton5)
								.addComponent(JButton1)
								.addComponent(JButton4)
								)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						)
);
		pack();
	}
	private void JButton5ActionPerformed(java.awt.event.ActionEvent evt) {
		state = true;
		Thread t = new Thread() {
			public void run() {
				for(;;) {
					if(state == true) {
						try {
							sleep(1);
							if(miliseconds >1000) {
								miliseconds = 0;
								seconds++;
								
							}
							if(seconds >60) {
								miliseconds = 0;
								seconds = 0;
								minutes++;
							}
							if(minutes >60) {
								miliseconds = 9;
								seconds = 0;
								minutes = 0;
								hours++;
							}
							milisecond.setText(" : "+miliseconds);
							miliseconds++;
							second.setText(" : "+seconds);
							minute.setText(" : "+minutes);
							hour.setText(" : "+hours);
						}
						catch(Exception e) {
							
						}
					}
					else {
						break;
					}
				}
			}
		};
		t.start();
		
	}
	private void JButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		state = false;
	}
	private void JButton4ActionPerformed(java.awt.event.ActionEvent evt) {
		state = false;
		
		hours = 0;
		minutes = 0;
		seconds = 0;
		miliseconds = 0;
		
		hour.setText("00 :");
		minute.setText("00 :");
		second.setText("00 :");
		milisecond.setText("00");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			for(javax.swing.UIManager.LookAndFeelInfo info: javax.swing.UIManager.getInstalledLookAndFeels() ) {
				if("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		}
		catch(ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(stopwatch.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
		}
		catch(InstantiationException ex) {
			java.util.logging.Logger.getLogger(stopwatch.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
		}
		catch(IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(stopwatch.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
		}
		catch(javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(stopwatch.class.getName()).log(java.util.logging.Level.SEVERE,null,ex);
		}
		
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new stopwatch().setVisible(true);
			}
		});
	}
	private javax.swing.JLabel hour;
	private javax.swing.JLabel minute;
	private javax.swing.JLabel second;
	private javax.swing.JLabel milisecond;
	private javax.swing.JButton JButton1;
	private javax.swing.JButton JButton4;
	private javax.swing.JButton JButton5;

	}


