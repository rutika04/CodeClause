import java.io.File;
import java.util.Scanner;

public class folderlocker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 Scanner scanner = new Scanner(System.in);
	     System.out.println("\t\t\tWelcome to Folder Locker Application");
	     
	     while(true) {
	    	 System.out.println("\n1.Lock a Folder");
	    	 System.out.println("2.Unlock a Folder");
	    	 System.out.println("3.Exit");
	    	 
	    	 System.out.println("Enter Your Choice:");
	    	 
	    	 int choice = scanner.nextInt();
	    	
	    	 switch(choice) {
	    	 
	    	 case 1:
	    		 	lockFolder();
	    		 break;
	    		 
	    	 case 2:
	    		 unlockFolder();
	    		 break;
	    		 
	    	 case 3:
	    		 System.out.println("Existing Folder Locker Application....");
	    		 System.out.println("Thank You..." + "Have a Nice Day!!");
	    		 scanner.close();
	    		 
	    		 System.exit(0);
	    		 break;
	    		 default:
	    			 System.out.println("Invalid Option.Please try again.");
	    	 
	    	 }
	     }
	        

	}
	
	private static void lockFolder() {
		Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the path of the folder to lock: ");
        String folderPath = scanner.nextLine();

        File folderToLock = new File(folderPath);

        if (!folderToLock.exists() || !folderToLock.isDirectory()) {
            System.out.println("Folder not found.");
            return;
        }

        File lockedFolder = new File(folderPath + "_locked");

        if (folderToLock.renameTo(lockedFolder)) {
        	secret1 en = secret1.getEncrypter(true);
			en.encrypt(lockedFolder, lockedFolder);
        	
            System.out.println("Folder locked successfully.");
        } else {
            System.out.println("Unable to lock the folder.");
        }
	}
	
	 private static void unlockFolder() {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter the path of the folder to unlock: ");
	        String folderPath = scanner.nextLine();

	        File lockedFolder = new File(folderPath);

	        if (!lockedFolder.exists() || !lockedFolder.isDirectory()) {
	            System.out.println("Locked folder not found.");
	            return;
	        }

	        File originalFolder = new File(folderPath.replace("_locked", ""));

	        if (lockedFolder.renameTo(originalFolder)) {
	        	secret2 de = secret2.getDecrypter(true);
	        	de.decrypt(originalFolder,originalFolder);
	            System.out.println("Folder unlocked successfully.");
	        } else {
	            System.out.println("Unable to unlock the folder.");
	        }
	    }

}
